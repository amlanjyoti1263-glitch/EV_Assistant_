# GitHub Actions Android Build

This project includes `.github/workflows/build-android.yml`.

## Build

1. Push the project to GitHub.
2. Open **Actions**.
3. Select **Build EV Assistant Android APK**.
4. Click **Run workflow** (or push to `main`/`master`).
5. When the job finishes, open the workflow run.
6. Download the artifact **EV-Assistant-Android10-debug**.

The workflow builds the existing Android project; it does not change the app's runtime behavior.
