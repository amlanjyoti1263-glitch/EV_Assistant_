# EV Assistant V13 FINAL — Android 10 Native Voice

This build is intentionally Android-first. The browser/hosted web path is not the target.

## Android target
- minSdk 29 (Android 10)
- targetSdk 29 (Android 10)
- Native `SpeechRecognizer` + native Android `TextToSpeech`
- App-owned WebView UI only
- YouTube original app/browser is never opened by the YouTube voice feature

## Voice lifecycle
- Microphone permission is requested at launch.
- After a voice result, hands-free intent remains enabled.
- Native recognition is automatically restarted after recognition errors/results and after Android TTS finishes.
- TTS temporarily stops recognition so the assistant does not hear its own voice.
- When the activity returns to foreground, recognition resumes automatically if hands-free mode was active.
- A manual Mic Stop clears the native hands-free intent.

## YouTube
Voice-only commands:
- `EV open youtube and search KGF`
- `EV KGF video open on youtube`
- `EV play video number 2`
- `EV pause video`
- `EV resume video`
- `EV stop video`
- `EV scroll down`
- `EV scroll up`
- `EV back`

The visible assistant screen shows five numbered results with thumbnails. Search metadata is collected by a hidden Android WebView and the selected video is loaded into the assistant-owned embedded player.


## Final video switching behavior
- If video #2 is playing and user says “EV play video number 5”, the current player is stopped and the exact stored video ID for result #5 is loaded.
- `EV scroll down/up` scrolls the assistant-owned result list only; it never opens the YouTube app.
- Numbered results keep their exact IDs until a new search replaces the result set.
- YouTube search uses the Android WebView path first (mobile YouTube page), with a desktop fallback and `ytInitialData`/DOM parsing.
- No YouTube search text box or external YouTube launch is required.
- Native Android speech lifecycle remains armed after every command/TTS response until the user explicitly stops the mic.
